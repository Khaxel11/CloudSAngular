'use strict'

var aire = require('../models/aire');
var fs = require('fs');
var path = require('path');

var controller = {
	
	home: function(req, res){
		return res.status(200).send({
			message: 'Soy aire'
		});
	},

	test: function(req, res){
		return res.status(200).send({
			message: "Soy el metodo o accion test del controlador de project"
		});
	},

	saveAire: function(req, res){
		var aire = new Aire();

		var params = req.body;
		aire.Temperatura = params.Temperatura;
		aire.Estado = params.Estado;
		aire.Online = params.Online;
		//aire.Password = params.Password;
		//aire.Telefono = params.Telefono;
		

		aire.save((err, projectStored) => {
			if(err) return res.status(500).send({message: 'Error al guardar el documento.'});

			if(!projectStored) return res.status(404).send({message: 'No se ha podido guardar el proyecto.'});

			return res.status(200).send({project: projectStored});
		});
	},

	getAire: function(req, res){
		var aireId = req.params.id;

		if(aireId == null) return res.status(404).send({message: 'El proyecto no existe.'});

		aire.findById(aireId, (err, aire) => {

			if(err) return res.status(500).send({message: 'Error al devolver los datos.'});

			if(!aire) return res.status(404).send({message: 'El proyecto no existe.'});

			return res.status(200).send({
				aire
			});

		});
	},

	getAires: function(req, res){

		aire.find({}).exec((err, aires) => {

			if(err) return res.status(500).send({message: 'Error al devolver los datos.'});

			if(!aires) return res.status(404).send({message: 'No hay projectos que mostrar.'});

			return res.status(200).send({aires});
		});

	}
};

module.exports = controller;